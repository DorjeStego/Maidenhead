from maidenhead.cli import main


def test_cli_normalize(capsys):
    code = main(["normalize", "IO83ri"])
    captured = capsys.readouterr()
    assert code == 0
    assert captured.out.strip() == "IO83ri"


def test_cli_validate_invalid():
    code = main(["validate", "IO83r!"])
    assert code == 2
