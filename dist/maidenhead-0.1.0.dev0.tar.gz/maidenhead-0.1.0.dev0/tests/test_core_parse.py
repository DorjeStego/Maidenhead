import pytest

from maidenhead import GridSquare, is_valid, normalize, parse, precision_of
from maidenhead.errors import InvalidLocatorError, PrecisionError


def test_normalize_casing():
    assert normalize("io83ri") == "IO83ri"
    assert normalize("Io83RI") == "IO83ri"
    assert normalize("IO83") == "IO83"


def test_is_valid_basic():
    assert is_valid("IO83")
    assert is_valid("IO83ri")
    assert not is_valid("IO8")
    assert not is_valid("IO83r!")


def test_parse_returns_gridsquare():
    gs = parse("IO83ri")
    assert isinstance(gs, GridSquare)
    assert gs.locator == "IO83ri"


def test_precision_of():
    assert precision_of("IO83") == 4
    assert precision_of(parse("IO83ri")) == 6


def test_normalize_rejects_invalid():
    with pytest.raises(PrecisionError):
        normalize("IO8")
    with pytest.raises(InvalidLocatorError):
        normalize("IO83r!")
